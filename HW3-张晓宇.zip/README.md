# HW3 - 比较并改进 Ray Serve 路由

## 一、环境信息

| 项目           | 版本                          |
| ------------ | --------------------------- |
| GPU          | NVIDIA RTX 6000D × 4 (84GB) |
| 操作系统         | AutoDL 容器 (Ubuntu 22.04)    |
| CUDA Version | 13.2                        |
| Python       | 3.10                        |
| SGLang       | 0.5.14                      |
| Ray          | 2.56.0                      |
| 模型           | Qwen/Qwen3-0.6B             |

## 二、安装方法

### 1. 创建虚拟环境

```bash
conda create -p /root/autodl-tmp/sglang python=3.10 -y
conda activate /root/autodl-tmp/sglang
```



### 2.安装依赖

```bash
pip install sglang==0.5.14 ray==2.56.0
pip install mmh3
```

### 3.下载负载

```bash
cd /root
source /etc/network_turbo
git clone https://github.com/Zirkland/26fall-HW-data.git
cd 26fall-HW-data/workloads/hw2/target3-routing-policies
pip install -r requirements.txt
python validate_workload.py mooncake_prefix_workload_v2_seed2026.jsonl
```

## 三、启动命令

### 1.启动四个SGLang服务

```bash
CUDA_VISIBLE_DEVICES=0 python3 -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B --host 0.0.0.0 --port 30000 \
  --page-size 64 --enable-cache-report \
  --attention-backend triton --disable-cuda-graph \
  --sampling-backend pytorch > /root/sglang_0.log 2>&1 &

CUDA_VISIBLE_DEVICES=1 python3 -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B --host 0.0.0.0 --port 30001 \
  --page-size 64 --enable-cache-report \
  --attention-backend triton --disable-cuda-graph \
  --sampling-backend pytorch > /root/sglang_1.log 2>&1 &

CUDA_VISIBLE_DEVICES=2 python3 -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B --host 0.0.0.0 --port 30002 \
  --page-size 64 --enable-cache-report \
  --attention-backend triton --disable-cuda-graph \
  --sampling-backend pytorch > /root/sglang_2.log 2>&1 &

CUDA_VISIBLE_DEVICES=3 python3 -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B --host 0.0.0.0 --port 30003 \
  --page-size 64 --enable-cache-report \
  --attention-backend triton --disable-cuda-graph \
  --sampling-backend pytorch > /root/sglang_3.log 2>&1 &
```



### 2.启动 Ray Serve

```BASH
A/B组
cd /root/autodl-tmp/sglang
python ray_serve_deploy.py > /root/ray_serve.log 2>&1 &
```

```bash
C组
export RAY_SERVE_SESSION_ID_HEADER_KEY=X-Prefix-Family
export PYTHONPATH=/root/autodl-tmp/sglang:$PYTHONPATH
cd /root/autodl-tmp/sglang
python ray_serve_deploy_C.py > /root/ray_serve_C.log 2>&1 &
```

```bash
D组
export RAY_SERVE_SESSION_ID_HEADER_KEY=X-Prefix-Family
export PYTHONPATH=/root/autodl-tmp/sglang:$PYTHONPATH
cd /root/autodl-tmp/sglang
python ray_serve_deploy_D.py > /root/ray_serve_D.log 2>&1 &
```



## 四、回放命令

```bash
cd /root/26fall-HW-data/workloads/hw2/target3-routing-policies

python run_workload.py \
  --policy serve \
  --run-name <RUN_NAME> \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --output-dir /root/results/<RUN_NAME> \
  --base-url http://127.0.0.1:8000 \
  --max-in-flight 8 \
  --model Qwen/Qwen3-0.6B \
  --router-name <ROUTER_NAME> \
  --max-ongoing-requests <MAX_ONGOING> \
  --expected-replicas 4 \
  --expected-backends 4 \
  --expected-nodes 5 \
  --overwrite
```

## 五、脚本用途

| 脚本                                | 用途                                                         |
| --------------------------------- | ---------------------------------------------------------- |
| src/target3/ray_serve_deploy.py   | A/B 组：默认 P2C 路由，测试 `max_ongoing_requests` 为 5、10、20        |
| src/target3/ray_serve_deploy_C.py | C 组：`ConsistentHashRouter` 纯前缀亲和，`num_fallback_replicas=0` |
| src/target3/ray_serve_deploy_D.py | D 组：自定义 `ImprovedRouter` 改进路由，前缀亲和 + 负载均衡                  |
| src/target3/custom_router_D.py    | D 组：路由逻辑，用 `X-Prefix-Family` 和 `get_queue_len()` 做决策       |

## 六、结果目录与报告表格对应关系



| 报告内容                                                           | 数据来源                                                                                                                           |
| -------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| Table 1：五组对照表（成功率、吞吐量、缓存命中率、实际 Prefill token、TTFT p95、端到端 p95） | 各 `summary.json` 的 `successful`、`throughput_rps`、`cache_hit_rate`、`computed_prefill_tokens_total`、`ttft_s.p95`、`latency_s.p95` |
| Figure 1：缓存命中率对比                                               | 各 `summary.json` 的 `cache_hit_rate`                                                                                            |
| Figure 2：TTFT p95 对比                                           | 各 `summary.json` 的 `ttft_s.p95`                                                                                                |
| Figure 3：端到端 p95 对比                                            | 各 `summary.json` 的 `latency_s.p95`                                                                                             |
| Figure 4：后端请求分布                                                | 各 `summary.json` 的 `backend_distribution`                                                                                      |
| Figure 5：superhot 族分布                                          | 各 `summary.json` 的 `popularity_tiers.superhot.backend_distribution`                                                            |
| Figure 6：三阶段（steady/burst/recovery）对比                          | 各 `summary.json` 的 `traffic_phases`                                                                                            |
