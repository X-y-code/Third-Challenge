import ray
from ray import serve
from ray.cluster_utils import Cluster
from fastapi import FastAPI, Request
from fastapi.responses import Response, StreamingResponse
import requests
import time
import re
import hashlib

SGLANG_PORTS = [30000, 30001, 30002, 30003]
NUM_REPLICAS = 4
MAX_ONGOING_REQUESTS = 20

def create_cluster():
    cluster = Cluster()
    cluster.add_node(num_cpus=2, num_gpus=0)
    for i in range(4):
        cluster.add_node(num_cpus=2, num_gpus=1)
    ray.init(address=cluster.address)
    print(f"Ray 集群已启动，head 地址：{cluster.address}")
    print(f"节点数：{len(cluster.list_all_nodes())}")
    return cluster

app = FastAPI()

@serve.deployment(
    num_replicas=NUM_REPLICAS,
    max_ongoing_requests=MAX_ONGOING_REQUESTS,
)
@serve.ingress(app)
class SGLangRouter:
    def __init__(self):
        self.sglang_port = None
        self.replica_rank = None
        # 在 __init__ 里确定端口，避免并发问题
        self._assign_port()

    def _assign_port(self):
        ctx = serve.get_replica_context()
        rank_obj = getattr(ctx, "rank", None)
        replica_id = str(ctx.replica_id)
        print(f"[INIT] rank_obj = {rank_obj}, type = {type(rank_obj)}")
        print(f"[INIT] replica_id = {replica_id}")

        rank = None
        # 尝试用 str(rank_obj) 提取数字
        if rank_obj is not None:
            s = str(rank_obj)
            m = re.search(r'\d+', s)
            if m:
                rank = int(m.group())

        # 回退到哈希
        if rank is None:
            rank = int(hashlib.md5(replica_id.encode()).hexdigest(), 16) % NUM_REPLICAS

        self.replica_rank = rank % NUM_REPLICAS
        self.sglang_port = SGLANG_PORTS[self.replica_rank]
        print(f"[INIT] Replica rank={self.replica_rank} 绑定到 SGLang 端口 {self.sglang_port}")

    def _routing_headers(self):
        return {
            "X-Ray-Replica-ID": f"replica-{self.replica_rank}",
            "X-Ray-Node-ID": f"node-{self.replica_rank}",
            "X-SGLang-Backend": f"sglang-{self.sglang_port}",
        }

    @app.post("/v1/chat/completions")
    async def chat_completions(self, request: Request):
        body = await request.json()
        url = f"http://127.0.0.1:{self.sglang_port}/v1/chat/completions"
        try:
            r = requests.post(url, json=body, timeout=120)
            return Response(
                content=r.content,
                media_type="application/json",
                headers=self._routing_headers(),
            )
        except Exception as e:
            return {"error": str(e)}

    @app.post("/generate")
    async def generate(self, request: Request):
        body = await request.json()
        url = f"http://127.0.0.1:{self.sglang_port}/generate"
        try:
            if body.get("stream"):
                r = requests.post(url, json=body, timeout=120, stream=True)
                def stream_gen():
                    for chunk in r.iter_content(chunk_size=None):
                        if chunk:
                            yield chunk
                return StreamingResponse(
                    stream_gen(),
                    media_type="text/event-stream",
                    headers=self._routing_headers(),
                )
            else:
                r = requests.post(url, json=body, timeout=120)
                return Response(
                    content=r.content,
                    media_type="application/json",
                    headers=self._routing_headers(),
                )
        except Exception as e:
            return {"error": str(e)}

    @app.post("/")
    async def root_chat(self, request: Request):
        return await self.chat_completions(request)

    @app.get("/v1/models")
    async def models(self):
        url = f"http://127.0.0.1:{self.sglang_port}/v1/models"
        try:
            r = requests.get(url, timeout=30)
            return Response(
                content=r.content,
                media_type="application/json",
                headers=self._routing_headers(),
            )
        except Exception as e:
            return {"error": str(e)}

if __name__ == "__main__":
    cluster = create_cluster()
    serve.start(http_options={"host": "0.0.0.0", "port": 8000})
    serve.run(SGLangRouter.bind())
    print("Ray Serve 已部署，HTTP 入口：http://0.0.0.0:8000")
    print("按 Ctrl+C 停止")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        serve.shutdown()
        ray.shutdown()
        cluster.shutdown()
        print("已停止")
