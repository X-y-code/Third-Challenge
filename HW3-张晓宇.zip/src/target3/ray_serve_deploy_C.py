import ray
from ray import serve
from ray.cluster_utils import Cluster
from fastapi import FastAPI, Request
from fastapi.responses import Response, StreamingResponse
import requests
import time
import re
import hashlib

SGLANG_PORTS = [30000, 30001, 30002, 30003]
NUM_REPLICAS = 4
MAX_ONGOING_REQUESTS = 20

def create_cluster():
    cluster = Cluster()
    cluster.add_node(num_cpus=2, num_gpus=0)
    for i in range(4):
        cluster.add_node(num_cpus=2, num_gpus=1)
    ray.init(address=cluster.address)
    print(f"Ray 集群已启动，head 地址：{cluster.address}")
    print(f"节点数：{len(cluster.list_all_nodes())}")
    return cluster

app = FastAPI()

from ray.serve.config import RequestRouterConfig

@serve.deployment(
    request_router_config=RequestRouterConfig(
        request_router_class=(
            "ray.serve.experimental.consistent_hash_router:ConsistentHashRouter"
        ),
        request_router_kwargs={"num_virtual_nodes": 100, "num_fallback_replicas": 0},
    ),
    num_replicas=NUM_REPLICAS,
    max_ongoing_requests=MAX_ONGOING_REQUESTS,
)
@serve.ingress(app)
class CGroupApp:
    def __init__(self):
        self.sglang_port = None
        self.replica_rank = None

    def _get_port(self):
        if self.sglang_port is None:
            ctx = serve.get_replica_context()
            rank_obj = getattr(ctx, "rank", None)
            replica_id = str(ctx.replica_id)
            rank = None
            if rank_obj is not None:
                s = str(rank_obj)
                m = re.search(r'rank=(\d+)', s)
                if m:
                    rank = int(m.group(1))
            if rank is None:
                rank = int(hashlib.md5(replica_id.encode()).hexdigest(), 16) % NUM_REPLICAS
            self.replica_rank = rank % NUM_REPLICAS
            self.sglang_port = SGLANG_PORTS[self.replica_rank]
            print(f"[C] Replica rank={self.replica_rank} 绑定到 SGLang 端口 {self.sglang_port}")
        return self.sglang_port

    def _routing_headers(self):
        return {
            "X-Ray-Replica-ID": f"replica-{self.replica_rank}",
            "X-Ray-Node-ID": f"node-{self.replica_rank}",
            "X-SGLang-Backend": f"sglang-{self.sglang_port}",
        }

    @app.post("/generate")
    async def generate(self, request: Request):
        port = self._get_port()
        body = await request.json()
        url = f"http://127.0.0.1:{port}/generate"
        try:
            if body.get("stream"):
                r = requests.post(url, json=body, timeout=120, stream=True)
                def stream_gen():
                    for chunk in r.iter_content(chunk_size=None):
                        if chunk:
                            yield chunk
                return StreamingResponse(
                    stream_gen(),
                    media_type="text/event-stream",
                    headers=self._routing_headers(),
                )
            else:
                r = requests.post(url, json=body, timeout=120)
                return Response(
                    content=r.content,
                    media_type="application/json",
                    headers=self._routing_headers(),
                )
        except Exception as e:
            return {"error": str(e)}

    @app.post("/")
    async def root_chat(self, request: Request):
        return await self.generate(request)

    @app.get("/v1/models")
    async def models(self):
        port = self._get_port()
        url = f"http://127.0.0.1:{port}/v1/models"
        try:
            r = requests.get(url, timeout=30)
            return Response(
                content=r.content,
                media_type="application/json",
                headers=self._routing_headers(),
            )
        except Exception as e:
            return {"error": str(e)}

if __name__ == "__main__":
    cluster = create_cluster()
    serve.start(http_options={"host": "0.0.0.0", "port": 8000})
    serve.run(CGroupApp.bind())
    print("Ray Serve (C 组) 已部署")
    print("按 Ctrl+C 停止")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        serve.shutdown()
        ray.shutdown()
        cluster.shutdown()
        print("已停止")
