from ray.serve.request_router import RequestRouter, PendingRequest, RunningReplica
from typing import List, Optional
import mmh3
import asyncio

THRESHOLD = 5  # 亲和副本队列超过 5 就切换

class ImprovedRouter(RequestRouter):
    async def _get_len(self, replica: RunningReplica) -> int:
        try:
            return await replica.get_queue_len(deadline_s=1.0)
        except Exception:
            return 0

    async def choose_replicas(
        self,
        candidate_replicas: List[RunningReplica],
        pending_request: Optional[PendingRequest] = None,
    ) -> List[List[RunningReplica]]:
        if not candidate_replicas:
            return []

        # 1. 提取前缀族
        prefix_family = None
        if pending_request is not None:
            headers = getattr(pending_request, "headers", {}) or {}
            prefix_family = headers.get("x-prefix-family") or headers.get("X-Prefix-Family")

        # 2. 哈希选亲和副本
        if prefix_family is not None:
            affinity_idx = mmh3.hash(str(prefix_family)) % len(candidate_replicas)
            affinity_replica = candidate_replicas[affinity_idx]

            # 3. 检查亲和副本负载（await）
            queue_len = await self._get_len(affinity_replica)

            if queue_len < THRESHOLD:
                return [[affinity_replica]]

        # 4. 亲和副本忙，选负载最低的
        lens = await asyncio.gather(*[self._get_len(r) for r in candidate_replicas])
        best_idx = min(range(len(candidate_replicas)), key=lambda i: lens[i])
        return [[candidate_replicas[best_idx]]]
